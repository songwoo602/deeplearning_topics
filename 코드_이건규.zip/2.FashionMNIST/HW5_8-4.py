# MLP for Pima Indians Dataset with 10-fold cross validation via sklearn
from keras.models import Sequential
from keras.layers import Dense
from keras.wrappers.scikit_learn import KerasClassifier
from sklearn.model_selection import StratifiedKFold
from sklearn.model_selection import cross_val_score
from keras.utils import np_utils
import numpy as np
# Function to create model, required for KerasClassifier
def create_model():
    # create model
    model = Sequential()
    model.add(Dense(num_pixels, input_dim=num_pixels, activation='relu'))
    model.add(Dense(392, activation='relu'))
    model.add(Dense(10, activation='sigmoid'))
    # Compile model
    model.compile(loss='categorical_crossentropy', optimizer='adam', metrics=['accuracy'])
    return model
# fix random seed for reproducibility
seed = 7
np.random.seed(seed)
# load pima indians dataset
dataset = np.loadtxt("c:/DeepLearning/data/fashion-mnist_train.csv", skiprows=1, delimiter=",")
# First row is label, so we have to skip first row

X_train = dataset[:,1:]
Y_train = dataset[:,0]

Y_train = np_utils.to_categorical(Y_train, num_classes=10)
num_pixels = len(X_train[0])

# create model
model = KerasClassifier(build_fn=create_model, epochs=15, batch_size=64, verbose=0)
# evaluate using 10-fold cross validation
kfold = StratifiedKFold(n_splits=10, shuffle=True, random_state=seed)
results = cross_val_score(model, X_train, Y_train, cv=kfold)
print(results.mean())