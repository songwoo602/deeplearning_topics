# MLP with manual validation set
from keras.models import Sequential
from keras.layers import Dense
from sklearn.model_selection import StratifiedKFold
from keras.utils import np_utils
import numpy as np
# fix random seed for reproducibility
seed = 7
np.random.seed(seed)
# load pima indians dataset
dataset = np.loadtxt("c:/DeepLearning/data/fashion-mnist_train.csv", skiprows=1, delimiter=",")
# First row is label, so we have to skip first row

X = dataset[:,1:]
Y = dataset[:,0]

dataset = np.loadtxt("c:/DeepLearning/data/fashion-mnist_test.csv", skiprows=1, delimiter=",")

X_test = dataset[:,1:]
Y_test = dataset[:,0]

# create model
Y = np_utils.to_categorical(Y, num_classes=10)
Y_test = np_utils.to_categorical(Y_test, num_classes=10)

# define 10-fold cross validation test harness
kfold = StratifiedKFold(n_splits=10, shuffle=True)
cvscores = []

num_pixels = len(X[0])

for train, test in kfold.split(X, Y):
    # create model
    model = Sequential()
    model.add(Dense(num_pixels, input_dim=num_pixels, activation='relu'))
    model.add(Dense(392, activation='relu'))
    model.add(Dense(10, activation='sigmoid'))
    # Compile model
    model.compile(loss='binary_crossentropy', optimizer='adam', metrics=['accuracy'])
    # Fit the model
    model.fit(X[train], Y[train], epochs=15, batch_size=64, verbose=0)
    # evaluate the model
    scores = model.evaluate(X[test], Y[test], verbose=0)
    print("%s: %.2f%%" % (model.metrics_names[1], scores[1]*100))
    cvscores.append(scores[1] * 100)
print("%.2f%% (+/- %.2f%%)" % (np.mean(cvscores), np.std(cvscores)))