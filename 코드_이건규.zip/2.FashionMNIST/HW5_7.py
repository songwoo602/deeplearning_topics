from keras.models import Sequential
from keras.layers import Dense
import numpy as np
from keras.utils import np_utils

np.random.seed(7)
dataset = np.loadtxt("c:/DeepLearning/data/fashion-mnist_train.csv", skiprows=1, delimiter=",")
# First row is label, so we have to skip first row

X_train = dataset[:,1:]
Y_train = dataset[:,0]

Y_train = np_utils.to_categorical(Y_train, num_classes=10)

num_pixels = len(X_train[0])

model = Sequential()
model.add(Dense(num_pixels, input_dim=num_pixels, activation='relu'))
model.add(Dense(392, activation='relu'))
model.add(Dense(10, activation='sigmoid'))
# Compile model
model.compile(loss='categorical_crossentropy', optimizer='adam', metrics=['accuracy'])
# Fit the model
model.fit(X_train, Y_train, epochs=15, batch_size=64)

scores = model.evaluate(X_train, Y_train)
print("\n%s: %.2f%%" % (model.metrics_names[1], scores[1]*100))