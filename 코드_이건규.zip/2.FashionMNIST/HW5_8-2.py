from keras.models import Sequential
from keras.layers import Dense, Dropout
from keras.utils import np_utils
from sklearn.model_selection import train_test_split
import matplotlib.pyplot as plt
import numpy as np

seed = 7
np.random.seed(seed)

dataset = np.loadtxt("c:/DeepLearning/data/fashion-mnist_train.csv", skiprows=1, delimiter=",")
# First row is label, so we have to skip first row
X_train = dataset[:,1:]
Y_train = dataset[:,0]

dataset = np.loadtxt("c:/DeepLearning/data/fashion-mnist_test.csv", skiprows=1, delimiter=",")
X_test = dataset[:,1:]
Y_test = dataset[:,0]

# create model
Y_train = np_utils.to_categorical(Y_train, num_classes=10)
Y_test = np_utils.to_categorical(Y_test, num_classes=10)
num_pixels = len(X_train[0])

model = Sequential()
model.add(Dense(num_pixels, input_dim=num_pixels, activation='relu'))
model.add(Dense(392, activation='relu'))
model.add(Dense(10, activation='sigmoid'))
# Compile model
model.compile(loss='categorical_crossentropy', optimizer='adam', metrics=['accuracy'])
# Fit the model
model.fit(X_train, Y_train, validation_data=(X_test,Y_test), epochs=15, batch_size=64)